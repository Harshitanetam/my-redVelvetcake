# INGREDIENTS

- 3 cups (360g) **cake flour** 
- 1 teaspoon **baking soda**
- 2 Tablespoons (10g) **unsweetened natural cocoa powder**
- 1/2 teaspoon **salt**
- 1/2 cup (115g) **unsalted butter**, softened 
- 2 cups (400g) **granulated sugar**
- 1 cup (240ml) **canola** or **vegetable oil**
- 4 large **eggs**, room temperature and separated
- 1 Tablespoon **pure vanilla extract**
- 1 teaspoon **distilled white vinegar**
- liquid or gel **red food coloring**
- 1 cup (240ml) **buttermilk**, at room temperature

